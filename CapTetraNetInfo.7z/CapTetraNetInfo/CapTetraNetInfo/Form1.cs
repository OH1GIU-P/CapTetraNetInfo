﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;

namespace CapTetraNetInfo
{
    public partial class Form1 : Form
    {

        public delegate bool WindowEnumDelegate(IntPtr hwnd, int lParam);

        [DllImport("user32.dll")]
        static extern IntPtr FindWindow(StringBuilder lpClassName, StringBuilder lpWindowName);
        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int wMsg, int wParam, StringBuilder lParam);
        [DllImport("user32.dll")]
        private static extern int GetWindowText(int hWnd, StringBuilder lpString, int length);
        [DllImport("user32.dll")]
        private static extern int GetWindowTextLength(int hWnd);
        [DllImport("user32.dll")]
        public static extern int EnumChildWindows(IntPtr hwnd, WindowEnumDelegate del, int lParam);
        [DllImport("user32.dll")]
        static extern uint RealGetWindowClass(IntPtr hwnd, StringBuilder pszType, uint cchType);
        [DllImport("user32.dll")]
        static extern void SwitchToThisWindow(IntPtr hWnd, bool turnOn);

        const int WM_GETTEXT = 13;
        const int WM_GETTEXTLENGTH = 14;
        const int SCR_DELAY = 4000;

        const string APP_CAP = "CapTetraNetInfo";

        bool run = false;
        int count = 0;
        StringBuilder netinfo = new StringBuilder();

        StringBuilder name = new StringBuilder("Network Info");

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            IntPtr hwnd = IntPtr.Zero;
            hwnd = FindWindow(null, name);
            if (hwnd == IntPtr.Zero)
            {
                MessageBox.Show("Cannot find Network Info window", APP_CAP, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                string logFile = @"c:\temp\" + DateTime.Now.ToString("yyyyMMddhhmmss") + "-netinfo.txt";
                netinfo.Clear();
                labelHwnd.Text = "SDR# TETRA plug-in netinfo window handle 0x" + hwnd.ToString("X");
                labelFile.Text = logFile;
                buttonStart.Enabled = false;
                buttonStop.Enabled = true;
                cbCC.Enabled = false;
                run = true;
                Application.DoEvents();
                WindowEnumDelegate del = new WindowEnumDelegate(WindowEnumProc);
                while (run)
                {
                    if (!cbCC.Checked)
                    {
                        EnumChildWindows(hwnd, del, 0);
                        File.WriteAllText(logFile, netinfo.ToString());
                        netinfo.Clear();
                    }
                    else
                    {
                        SwitchToThisWindow(hwnd, true);
                        SendKeys.SendWait("^a");
                        SendKeys.SendWait("^c");
                        File.AppendAllText(logFile, Clipboard.GetText());
                        count++;
                    }
                    labelCnt.Text = count.ToString();
                    Application.DoEvents();
                    System.Threading.Thread.Sleep(SCR_DELAY);
                    Application.DoEvents();
                }
            }
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            run = false;
            count = 0;
            labelHwnd.Text = "NULL";
            labelCnt.Text = "0";
            labelFile.Text = "NULL";
            buttonStart.Enabled = true;
            buttonStop.Enabled = false;
            cbCC.Enabled = true;
        }

        private bool WindowEnumProc(IntPtr ctrl, int lParam)
        {
            int len = 0;
            StringBuilder data;
            StringBuilder className = new StringBuilder(1024);

            RealGetWindowClass(ctrl, className, 1024);
            len = SendMessage(ctrl, WM_GETTEXTLENGTH, 0, null);
            if (len != 0)
            {
                data = new StringBuilder(len);
                SendMessage(ctrl, WM_GETTEXT, (len + 1), data);
                netinfo.Append(data);
                count++;
            }
            return true;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            run = false;
        }
    }
}
