﻿namespace CapTetraNetInfo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.labelHwnd = new System.Windows.Forms.Label();
            this.labelCnt = new System.Windows.Forms.Label();
            this.cbCC = new System.Windows.Forms.CheckBox();
            this.labelFile = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(16, 36);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(120, 23);
            this.buttonStart.TabIndex = 0;
            this.buttonStart.Text = "Start capture";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Enabled = false;
            this.buttonStop.Location = new System.Drawing.Point(172, 36);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(120, 23);
            this.buttonStop.TabIndex = 1;
            this.buttonStop.Text = "Stop capture";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // labelHwnd
            // 
            this.labelHwnd.AutoSize = true;
            this.labelHwnd.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHwnd.Location = new System.Drawing.Point(13, 83);
            this.labelHwnd.Name = "labelHwnd";
            this.labelHwnd.Size = new System.Drawing.Size(40, 16);
            this.labelHwnd.TabIndex = 2;
            this.labelHwnd.Text = "NULL";
            // 
            // labelCnt
            // 
            this.labelCnt.AutoSize = true;
            this.labelCnt.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCnt.Location = new System.Drawing.Point(12, 106);
            this.labelCnt.Name = "labelCnt";
            this.labelCnt.Size = new System.Drawing.Size(16, 16);
            this.labelCnt.TabIndex = 3;
            this.labelCnt.Text = "0";
            // 
            // cbCC
            // 
            this.cbCC.AutoSize = true;
            this.cbCC.Location = new System.Drawing.Point(335, 41);
            this.cbCC.Name = "cbCC";
            this.cbCC.Size = new System.Drawing.Size(96, 17);
            this.cbCC.TabIndex = 4;
            this.cbCC.Text = "Clipboard copy";
            this.cbCC.UseVisualStyleBackColor = true;
            // 
            // labelFile
            // 
            this.labelFile.AutoSize = true;
            this.labelFile.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFile.Location = new System.Drawing.Point(12, 132);
            this.labelFile.Name = "labelFile";
            this.labelFile.Size = new System.Drawing.Size(40, 16);
            this.labelFile.TabIndex = 5;
            this.labelFile.Text = "NULL";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 176);
            this.Controls.Add(this.labelFile);
            this.Controls.Add(this.cbCC);
            this.Controls.Add(this.labelCnt);
            this.Controls.Add(this.labelHwnd);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonStart);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CapTetraNetInfo";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Label labelHwnd;
        private System.Windows.Forms.Label labelCnt;
        private System.Windows.Forms.CheckBox cbCC;
        private System.Windows.Forms.Label labelFile;
    }
}

